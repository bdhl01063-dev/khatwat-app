import {
  analyzeProfileLocally,
  FINANCIAL_DISCLAIMER_AR,
  getBudgetLabel,
  SKILL_OPTIONS,
  INTEREST_OPTIONS,
  LOCATION_OPTIONS
} from './engine.js';

const GEMINI_ENDPOINT =
  'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent';

/**
 * Runs local offline analysis immediately, and ONLY if the user explicitly enabled
 * and provided a free Google AI Studio key AND is online, attempts optional Gemini
 * phrasing/refinement with silent, guaranteed fallback to local results.
 */
export async function analyzeWithOptionalGemini(
  profile,
  revisionNote = '',
  { apiKey = '', useOptionalGemini = false, fetchFn = typeof fetch === 'function' ? fetch : null } = {}
) {
  const localResult = analyzeProfileLocally(profile, revisionNote);

  const trimmedKey = String(apiKey || '').trim();
  const isOnline = typeof navigator === 'undefined' ? true : navigator.onLine !== false;

  if (!useOptionalGemini || !trimmedKey || !isOnline || !fetchFn) {
    return {
      ...localResult,
      fallbackNotice: ''
    };
  }

  const skillLabels = (profile.skills || [])
    .map((id) => SKILL_OPTIONS.find((s) => s.id === id)?.label)
    .filter(Boolean)
    .join('، ');
  const interestLabels = (profile.interests || [])
    .map((id) => INTEREST_OPTIONS.find((i) => i.id === id)?.label)
    .filter(Boolean)
    .join('، ');
  const locLabel =
    LOCATION_OPTIONS.find((l) => l.id === profile.locationPreference)?.label || 'مرن';

  const prompt = `أنت مستشار مشاريع صغيرة للشباب في اليمن. أعطِ 3 أفكار مشاريع عملية باللغة العربية الفصحى السهلة فقط بصيغة JSON مطابقة للبنية التالية، بالريال اليمني (YER)، وبواقعية تامة دون وعود مضمونة:
المهارات: ${skillLabels || 'عامة'} ${profile.customSkills ? '+ ' + profile.customSkills : ''}
الاهتمامات: ${interestLabels || 'متنوعة'} ${profile.passionNote ? '+ ' + profile.passionNote : ''}
الميزانية: ${getBudgetLabel(profile)}
طبيعة العمل: ${locLabel}
المدينة: ${profile.city || 'غير محددة'}
${revisionNote ? 'ملاحظة التعديل: ' + revisionNote : ''}

أعد كائن JSON فقط يحتوي على مصفوفة "ideas" من 3 عناصر، كل عنصر فيه:
title, summary, workModeLabel, reasons (مصفوفة 3 أسباب), startupRangeLabel, monthlyExpense, monthlyRevenue, breakEven, startupItems (مصفوفة {item, range}), steps (مصفوفة 5 عناصر {title, description, timeframe}), marketing ({targetAudience, channels (3 عناصر), firstWeekActions, pricingTip}).`;

  const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = controller ? setTimeout(() => controller.abort(), 18000) : null;

  try {
    const response = await fetchFn(`${GEMINI_ENDPOINT}?key=${encodeURIComponent(trimmedKey)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: controller ? controller.signal : undefined,
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: {
          responseMimeType: 'application/json',
          temperature: 0.7
        }
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const payload = await response.json();
    const rawText = payload?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!rawText) {
      throw new Error('Empty Gemini response');
    }

    const parsed = JSON.parse(rawText);
    if (!Array.isArray(parsed.ideas) || parsed.ideas.length < 3) {
      throw new Error('Incomplete ideas array');
    }

    const normalizedIdeas = parsed.ideas.slice(0, 3).map((item, idx) => ({
      id: `gemini_idea_${idx + 1}_${Date.now()}`,
      rank: idx + 1,
      title: String(item.title || localResult.ideas[idx].title),
      summary: String(item.summary || localResult.ideas[idx].summary),
      workModeLabel: String(item.workModeLabel || localResult.ideas[idx].workModeLabel),
      reasons:
        Array.isArray(item.reasons) && item.reasons.length > 0
          ? item.reasons.map(String)
          : localResult.ideas[idx].reasons,
      financials: {
        startupRangeLabel: String(
          item.startupRangeLabel || localResult.ideas[idx].financials.startupRangeLabel
        ),
        startupItems:
          Array.isArray(item.startupItems) && item.startupItems.length > 0
            ? item.startupItems.map((c) => ({
                item: String(c.item || 'بند تأسيسي'),
                range: String(c.range || 'تقدير تقريبي')
              }))
            : localResult.ideas[idx].financials.startupItems,
        monthlyExpense: String(
          item.monthlyExpense || localResult.ideas[idx].financials.monthlyExpense
        ),
        monthlyRevenue: String(
          item.monthlyRevenue || localResult.ideas[idx].financials.monthlyRevenue
        ),
        breakEven: String(item.breakEven || localResult.ideas[idx].financials.breakEven),
        disclaimer: FINANCIAL_DISCLAIMER_AR
      },
      steps:
        Array.isArray(item.steps) && item.steps.length > 0
          ? item.steps.map((s, sIdx) => ({
              id: `gemini_${idx + 1}_step_${sIdx + 1}`,
              title: String(s.title || `خطوة ${sIdx + 1}`),
              description: String(s.description || ''),
              timeframe: String(s.timeframe || 'الأسبوع الأول'),
              completed: false
            }))
          : localResult.ideas[idx].steps,
      marketing: {
        targetAudience: String(
          item.marketing?.targetAudience || localResult.ideas[idx].marketing.targetAudience
        ),
        channels:
          Array.isArray(item.marketing?.channels) && item.marketing.channels.length > 0
            ? item.marketing.channels.map(String)
            : localResult.ideas[idx].marketing.channels,
        firstWeekActions: String(
          item.marketing?.firstWeekActions || localResult.ideas[idx].marketing.firstWeekActions
        ),
        pricingTip: String(item.marketing?.pricingTip || localResult.ideas[idx].marketing.pricingTip)
      }
    }));

    return {
      source: 'gemini_optional',
      sourceLabel: 'معزز اختيارياً عبر Gemini المجاني (مع توافر العمل المحلي)',
      disclaimer: FINANCIAL_DISCLAIMER_AR,
      revisionNote: String(revisionNote || '').trim(),
      fallbackNotice: '',
      ideas: normalizedIdeas
    };
  } catch {
    return {
      ...localResult,
      fallbackNotice:
        'تعذر الاتصال بخدمة Gemini المجانية الاختيارية، لذلك تم اعتماد نتائج المحرك المحلي فوراً دون توقف.'
    };
  } finally {
    if (timer) clearTimeout(timer);
  }
}
