const PLANS_STORAGE_KEY = 'khatwat_saved_plans_v1';
const DRAFT_STORAGE_KEY = 'khatwat_wizard_draft_v1';
const OPTIONAL_GEMINI_KEY_STORAGE = 'khatwat_optional_gemini_key_v1';

function resolveStorage(customStorage) {
  if (customStorage) return customStorage;
  if (typeof window !== 'undefined' && window.localStorage) {
    return window.localStorage;
  }
  return null;
}

export function loadSavedPlans(customStorage) {
  const store = resolveStorage(customStorage);
  if (!store) return [];
  try {
    const raw = store.getItem(PLANS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveAllPlans(plans, customStorage) {
  const store = resolveStorage(customStorage);
  if (!store) return false;
  try {
    store.setItem(PLANS_STORAGE_KEY, JSON.stringify(plans));
    return true;
  } catch {
    return false;
  }
}

export function upsertSavedPlan(planBundle, customStorage) {
  const plans = loadSavedPlans(customStorage);
  const existingIndex = plans.findIndex((p) => p.id === planBundle.id);
  const updated = {
    ...planBundle,
    updatedAt: Date.now()
  };
  if (existingIndex >= 0) {
    plans[existingIndex] = updated;
  } else {
    plans.unshift(updated);
  }
  saveAllPlans(plans, customStorage);
  return plans;
}

export function deleteSavedPlan(planId, customStorage) {
  const plans = loadSavedPlans(customStorage).filter((p) => p.id !== planId);
  saveAllPlans(plans, customStorage);
  return plans;
}

export function toggleStepInSavedPlan(planId, ideaId, stepId, customStorage) {
  const plans = loadSavedPlans(customStorage);
  const planIdx = plans.findIndex((p) => p.id === planId);
  if (planIdx < 0) return null;

  const plan = plans[planIdx];
  const updatedIdeas = (plan.ideas || []).map((idea) => {
    if (idea.id !== ideaId) return idea;
    return {
      ...idea,
      steps: (idea.steps || []).map((step) =>
        step.id === stepId ? { ...step, completed: !step.completed } : step
      )
    };
  });

  plans[planIdx] = {
    ...plan,
    ideas: updatedIdeas,
    updatedAt: Date.now()
  };
  saveAllPlans(plans, customStorage);
  return plans[planIdx];
}

export function loadWizardDraft(customStorage) {
  const store = resolveStorage(customStorage);
  if (!store) return null;
  try {
    const raw = store.getItem(DRAFT_STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function saveWizardDraft(profile, customStorage) {
  const store = resolveStorage(customStorage);
  if (!store) return false;
  try {
    store.setItem(DRAFT_STORAGE_KEY, JSON.stringify(profile));
    return true;
  } catch {
    return false;
  }
}

export function clearWizardDraft(customStorage) {
  const store = resolveStorage(customStorage);
  if (!store) return;
  try {
    store.removeItem(DRAFT_STORAGE_KEY);
  } catch {
    // ignore
  }
}

export function getOptionalGeminiKey(customStorage) {
  const store = resolveStorage(customStorage);
  if (!store) return '';
  try {
    return (store.getItem(OPTIONAL_GEMINI_KEY_STORAGE) || '').trim();
  } catch {
    return '';
  }
}

export function setOptionalGeminiKey(apiKey, customStorage) {
  const store = resolveStorage(customStorage);
  if (!store) return;
  const cleaned = String(apiKey || '').trim();
  if (!cleaned) {
    store.removeItem(OPTIONAL_GEMINI_KEY_STORAGE);
  } else {
    store.setItem(OPTIONAL_GEMINI_KEY_STORAGE, cleaned);
  }
}

export function calculatePlanProgress(plan) {
  let total = 0;
  let done = 0;
  for (const idea of plan?.ideas || []) {
    for (const step of idea.steps || []) {
      total += 1;
      if (step.completed) done += 1;
    }
  }
  if (total === 0) return { done: 0, total: 0, percent: 0 };
  return { done, total, percent: Math.round((done / total) * 100) };
}
