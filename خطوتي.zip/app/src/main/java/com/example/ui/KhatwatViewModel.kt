package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.PlanRepository
import com.example.domain.BusinessPlanBundle
import com.example.domain.KhatwatPlanAnalyzer
import com.example.domain.PlanAnalyzer
import com.example.domain.QuestionnaireProfile
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class AppScreen {
    LANDING,
    WIZARD,
    RESULTS,
    DETAIL,
    SAVED
}

enum class DetailTab {
    STEPS,
    FINANCIALS,
    MARKETING
}

sealed interface AnalysisUiState {
    data object Idle : AnalysisUiState
    data object Loading : AnalysisUiState
    data class Success(val bundle: BusinessPlanBundle) : AnalysisUiState
    data class Error(val message: String) : AnalysisUiState
}

data class KhatwatUiState(
    val currentScreen: AppScreen = AppScreen.LANDING,
    val wizardStep: Int = 1,
    val profile: QuestionnaireProfile = QuestionnaireProfile(),
    val wizardError: String? = null,
    val analysisState: AnalysisUiState = AnalysisUiState.Idle,
    val selectedIdeaId: String? = null,
    val detailTab: DetailTab = DetailTab.STEPS,
    val showReviseSheet: Boolean = false,
    val useOptionalGemini: Boolean = false,
    val optionalGeminiKey: String = ""
)

class KhatwatViewModel(
    private val repository: PlanRepository,
    private val analyzer: PlanAnalyzer = KhatwatPlanAnalyzer()
) : ViewModel() {

    private val _uiState = MutableStateFlow(KhatwatUiState())
    val uiState: StateFlow<KhatwatUiState> = _uiState.asStateFlow()

    val savedPlans: StateFlow<List<BusinessPlanBundle>> = repository.savedPlans
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _snackbarEvents = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val snackbarEvents: SharedFlow<String> = _snackbarEvents.asSharedFlow()

    fun navigateToLanding() {
        _uiState.update { it.copy(currentScreen = AppScreen.LANDING, wizardError = null) }
    }

    fun startFreshWizard() {
        _uiState.update {
            it.copy(
                currentScreen = AppScreen.WIZARD,
                wizardStep = 1,
                profile = QuestionnaireProfile(),
                wizardError = null
            )
        }
    }

    fun openSavedPlans() {
        _uiState.update { it.copy(currentScreen = AppScreen.SAVED, wizardError = null) }
    }

    fun openSavedBundle(bundle: BusinessPlanBundle) {
        _uiState.update {
            it.copy(
                currentScreen = AppScreen.RESULTS,
                profile = bundle.profile,
                analysisState = AnalysisUiState.Success(bundle),
                selectedIdeaId = bundle.ideas.firstOrNull()?.id
            )
        }
    }

    fun deleteSavedPlan(planId: String) {
        viewModelScope.launch {
            repository.deletePlan(planId)
            _snackbarEvents.tryEmit("تم حذف الخطة من جهازك.")
        }
    }

    fun toggleSkill(skillId: String) {
        _uiState.update { state ->
            val updated = state.profile.skills.toMutableList()
            if (skillId in updated) updated.remove(skillId) else updated.add(skillId)
            state.copy(profile = state.profile.copy(skills = updated), wizardError = null)
        }
    }

    fun addCustomSkill(rawSkill: String) {
        val cleaned = rawSkill.trim()
        if (cleaned.isEmpty()) return
        _uiState.update { state ->
            val updated = state.profile.customSkills.toMutableList()
            if (cleaned !in updated) updated.add(cleaned)
            state.copy(profile = state.profile.copy(customSkills = updated), wizardError = null)
        }
    }

    fun removeCustomSkill(skill: String) {
        _uiState.update { state ->
            state.copy(
                profile = state.profile.copy(
                    customSkills = state.profile.customSkills.filterNot { it == skill }
                )
            )
        }
    }

    fun selectExperience(experienceId: String) {
        _uiState.update { it.copy(profile = it.profile.copy(experienceId = experienceId)) }
    }

    fun toggleInterest(interestId: String) {
        _uiState.update { state ->
            val updated = state.profile.interests.toMutableList()
            if (interestId in updated) updated.remove(interestId) else updated.add(interestId)
            state.copy(profile = state.profile.copy(interests = updated), wizardError = null)
        }
    }

    fun updatePassionNote(note: String) {
        _uiState.update { it.copy(profile = it.profile.copy(passionNote = note), wizardError = null) }
    }

    fun selectBudget(budgetId: String) {
        _uiState.update {
            it.copy(
                profile = it.profile.copy(budgetId = budgetId, customBudgetYer = ""),
                wizardError = null
            )
        }
    }

    fun updateCustomBudget(rawAmount: String) {
        val digitsOnly = buildString {
            for (ch in rawAmount) {
                when (ch) {
                    in '0'..'9' -> append(ch)
                    in '٠'..'٩' -> append(('0'.code + (ch.code - '٠'.code)).toChar())
                    in '۰'..'۹' -> append(('0'.code + (ch.code - '۰'.code)).toChar())
                }
            }
        }
        _uiState.update {
            it.copy(profile = it.profile.copy(customBudgetYer = digitsOnly), wizardError = null)
        }
    }

    fun selectHours(hoursId: String) {
        _uiState.update { it.copy(profile = it.profile.copy(hoursId = hoursId)) }
    }

    fun selectLocation(locationId: String) {
        _uiState.update { it.copy(profile = it.profile.copy(locationPreference = locationId)) }
    }

    fun toggleTool(toolId: String) {
        _uiState.update { state ->
            val updated = state.profile.tools.toMutableList()
            if (toolId in updated) updated.remove(toolId) else updated.add(toolId)
            state.copy(profile = state.profile.copy(tools = updated), wizardError = null)
        }
    }

    fun updateCity(city: String) {
        _uiState.update { it.copy(profile = it.profile.copy(city = city)) }
    }

    fun setOptionalGemini(enabled: Boolean, apiKey: String) {
        _uiState.update { it.copy(useOptionalGemini = enabled, optionalGeminiKey = apiKey) }
    }

    fun previousWizardStep() {
        _uiState.update { state ->
            if (state.wizardStep > 1) {
                state.copy(wizardStep = state.wizardStep - 1, wizardError = null)
            } else {
                state.copy(currentScreen = AppScreen.LANDING, wizardError = null)
            }
        }
    }

    fun nextWizardStep() {
        val state = _uiState.value
        val error = validateStep(state.wizardStep, state.profile)
        if (error != null) {
            _uiState.update { it.copy(wizardError = error) }
            return
        }
        if (state.wizardStep < 4) {
            _uiState.update { it.copy(wizardStep = it.wizardStep + 1, wizardError = null) }
        }
    }

    fun submitWizard(revisionNote: String = "") {
        val state = _uiState.value
        val error = validateStep(4, state.profile)
        if (error != null) {
            _uiState.update { it.copy(wizardError = error) }
            return
        }
        runAnalysis(state.profile, revisionNote)
    }

    private fun runAnalysis(profile: QuestionnaireProfile, revisionNote: String) {
        val stateSnapshot = _uiState.value
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    currentScreen = AppScreen.RESULTS,
                    analysisState = AnalysisUiState.Loading,
                    showReviseSheet = false
                )
            }
            try {
                val bundle = analyzer.analyze(
                    profile = profile,
                    revisionNote = revisionNote,
                    useOptionalGemini = stateSnapshot.useOptionalGemini,
                    optionalApiKey = stateSnapshot.optionalGeminiKey
                )
                repository.savePlan(bundle)
                _uiState.update {
                    it.copy(
                        analysisState = AnalysisUiState.Success(bundle),
                        selectedIdeaId = bundle.ideas.firstOrNull()?.id
                    )
                }
                _snackbarEvents.tryEmit("تم إنشاء 3 أفكار مشاريع وحفظها محلياً على جهازك.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        analysisState = AnalysisUiState.Error(
                            e.localizedMessage ?: "حدث خطأ غير متوقع أثناء تحليل الخطة."
                        )
                    )
                }
            }
        }
    }

    fun openIdeaDetail(ideaId: String) {
        _uiState.update {
            it.copy(
                currentScreen = AppScreen.DETAIL,
                selectedIdeaId = ideaId,
                detailTab = DetailTab.STEPS
            )
        }
    }

    fun backFromDetailToResults() {
        _uiState.update { it.copy(currentScreen = AppScreen.RESULTS) }
    }

    fun selectDetailTab(tab: DetailTab) {
        _uiState.update { it.copy(detailTab = tab) }
    }

    private val dbSaveMutex = kotlinx.coroutines.sync.Mutex()

    fun toggleStepCompletion(ideaId: String, stepId: String) {
        val successState = _uiState.value.analysisState as? AnalysisUiState.Success ?: return
        val currentBundle = successState.bundle
        val updatedBundle = currentBundle.copy(
            updatedAt = System.currentTimeMillis(),
            ideas = currentBundle.ideas.map { idea ->
                if (idea.id != ideaId) idea
                else idea.copy(
                    steps = idea.steps.map { step ->
                        if (step.id == stepId) step.copy(completed = !step.completed) else step
                    }
                )
            }
        )
        _uiState.update { it.copy(analysisState = AnalysisUiState.Success(updatedBundle)) }
        viewModelScope.launch {
            dbSaveMutex.lock()
            try {
                repository.savePlan(updatedBundle)
            } finally {
                dbSaveMutex.unlock()
            }
        }
    }

    fun saveCurrentPlanExplicitly() {
        val successState = _uiState.value.analysisState as? AnalysisUiState.Success ?: return
        viewModelScope.launch {
            repository.savePlan(successState.bundle)
            _snackbarEvents.tryEmit("تم حفظ الخطة في «خططي المحفوظة» للعمل دون إنترنت.")
        }
    }

    fun openReviseSheet() {
        _uiState.update { it.copy(showReviseSheet = true) }
    }

    fun dismissReviseSheet() {
        _uiState.update { it.copy(showReviseSheet = false) }
    }

    fun applyRevisionNote(note: String) {
        val currentProfile = (_uiState.value.analysisState as? AnalysisUiState.Success)?.bundle?.profile
            ?: _uiState.value.profile
        runAnalysis(currentProfile, note.trim())
    }

    fun editQuestionnaireFromRevise() {
        val activeProfile = (_uiState.value.analysisState as? AnalysisUiState.Success)?.bundle?.profile
            ?: _uiState.value.profile
        _uiState.update {
            it.copy(
                showReviseSheet = false,
                profile = activeProfile,
                wizardStep = 1,
                currentScreen = AppScreen.WIZARD,
                wizardError = null
            )
        }
    }

    fun validateStep(step: Int, profile: QuestionnaireProfile): String? = when (step) {
        1 -> if (profile.skills.isEmpty() && profile.customSkills.isEmpty()) {
            "يرجى اختيار مهارة واحدة على الأقل أو إضافة مهارة مخصصة للمتابعة."
        } else null
        2 -> if (profile.interests.isEmpty() && profile.passionNote.isBlank()) {
            "يرجى اختيار مجال اهتمام واحد على الأقل أو كتابة نبذة مختصرة."
        } else null
        3 -> {
            val custom = profile.customBudgetYer.trim().toLongOrNull()
            if (profile.customBudgetYer.isNotBlank() && (custom == null || custom < 0L)) {
                "يرجى إدخال مبلغ صحيح بالريال اليمني (0 أو أكثر)."
            } else null
        }
        4 -> if (profile.tools.isEmpty()) {
            "يرجى تحديد أداة واحدة متوفرة لديك على الأقل (مثل الهاتف الذكي)."
        } else null
        else -> null
    }

    class Factory(
        private val repository: PlanRepository,
        private val analyzer: PlanAnalyzer = KhatwatPlanAnalyzer()
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return KhatwatViewModel(repository, analyzer) as T
        }
    }
}
