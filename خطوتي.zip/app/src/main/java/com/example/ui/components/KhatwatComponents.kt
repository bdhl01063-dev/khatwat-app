package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.OfflineBolt
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ErrorRedBg
import com.example.ui.theme.Navy100
import com.example.ui.theme.Navy50
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.Orange100
import com.example.ui.theme.Orange200
import com.example.ui.theme.Orange400
import com.example.ui.theme.Orange500
import com.example.ui.theme.Orange600
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuccessGreenBg
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmberBg
import com.example.ui.theme.WarningAmberBorder
import com.example.ui.theme.WarningAmberText

@Composable
fun KhatwatTopBar(
    savedCount: Int,
    onBrandClick: () -> Unit,
    onSavedClick: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Surface(
            color = Navy900,
            contentColor = PureWhite,
            shadowElevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable(onClick = onBrandClick)
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                        .testTag("brand_home_button"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Navy800),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.Bottom,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Box(Modifier.size(width = 5.dp, height = 8.dp).background(Orange500, RoundedCornerShape(2.dp)))
                            Box(Modifier.size(width = 5.dp, height = 14.dp).background(Orange400, RoundedCornerShape(2.dp)))
                            Box(Modifier.size(width = 5.dp, height = 20.dp).background(PureWhite, RoundedCornerShape(2.dp)))
                        }
                    }
                    Column {
                        Text(
                            text = "خطوتك",
                            style = MaterialTheme.typography.titleLarge,
                            color = PureWhite,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "مساعد المشاريع الصغيرة",
                            style = MaterialTheme.typography.labelSmall,
                            color = Orange400
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = PureWhite.copy(alpha = 0.1f),
                    border = BorderStroke(1.dp, PureWhite.copy(alpha = 0.22f)),
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .clip(RoundedCornerShape(999.dp))
                        .clickable(onClick = onSavedClick)
                        .testTag("topbar_saved_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Bookmark,
                            contentDescription = "خططي المحفوظة",
                            tint = Orange400,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "خططي",
                            style = MaterialTheme.typography.labelLarge,
                            color = PureWhite
                        )
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Orange500)
                                .padding(horizontal = 7.dp, vertical = 2.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = savedCount.toString(),
                                style = MaterialTheme.typography.labelSmall,
                                color = PureWhite,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        Surface(
            color = Navy800,
            contentColor = PureWhite
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.OfflineBolt,
                        contentDescription = null,
                        tint = Color(0xFF4ADE80),
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "الوضع المحلي المجاني 100% — يعمل دون إنترنت",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFFDBEAFE)
                    )
                }
                Text(
                    text = "YER · مجاني",
                    style = MaterialTheme.typography.labelSmall,
                    color = Orange400,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun SelectablePillChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    accentOrange: Boolean = false
) {
    val bg = when {
        selected && accentOrange -> Orange500
        selected -> Navy900
        else -> PureWhite
    }
    val fg = if (selected) PureWhite else Navy900
    val border = if (selected) bg else BorderSubtle

    Surface(
        shape = RoundedCornerShape(999.dp),
        color = bg,
        border = BorderStroke(1.5.dp, border),
        modifier = modifier
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(999.dp))
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (selected) {
                Icon(
                    imageVector = Icons.Rounded.Check,
                    contentDescription = null,
                    tint = PureWhite,
                    modifier = Modifier.size(16.dp)
                )
            }
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = fg,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}

@Composable
fun OptionSelectCard(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (selected) Orange100 else PureWhite,
        border = BorderStroke(1.5.dp, if (selected) Orange500 else BorderSubtle),
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = Navy900,
                    fontWeight = FontWeight.Bold
                )
                if (subtitle.isNotEmpty()) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            if (selected) {
                Spacer(Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(Orange500),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Check,
                        contentDescription = "محدد",
                        tint = PureWhite,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AlertBanner(
    text: String,
    type: AlertBannerType,
    modifier: Modifier = Modifier
) {
    val (bg, border, fg, icon) = when (type) {
        AlertBannerType.WARNING -> Quadruple(WarningAmberBg, WarningAmberBorder, WarningAmberText, Icons.Rounded.WarningAmber)
        AlertBannerType.ERROR -> Quadruple(ErrorRedBg, Color(0xFFFECACA), ErrorRed, Icons.Rounded.WarningAmber)
        AlertBannerType.INFO -> Quadruple(Navy50, Navy100, Navy800, Icons.Rounded.Info)
        AlertBannerType.SUCCESS -> Quadruple(SuccessGreenBg, Color(0xFFBBF7D0), SuccessGreen, Icons.Rounded.Check)
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = bg,
        border = BorderStroke(1.dp, border),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = fg,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium,
                color = fg,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

enum class AlertBannerType { WARNING, ERROR, INFO, SUCCESS }

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun RevisePlanSheet(
    onDismiss: () -> Unit,
    onApplyFeedback: (String) -> Unit,
    onEditQuestionnaire: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var note by remember { mutableStateOf("") }

    val quickOptions = listOf(
        "أقل تكلفة" to "أريد أفكاراً بتكلفة أقل أو بدون رأس مال",
        "عن بُعد فقط" to "أفضل العمل عن بُعد بالكامل عبر الإنترنت",
        "بالهاتف فقط" to "أريد أفكاراً تناسب الهاتف فقط بدون لابتوب",
        "من المنزل + واتساب" to "ركّز على العمل من المنزل والتسويق عبر واتساب"
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = PureWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "تعديل الخطة وتخصيصها",
                    style = MaterialTheme.typography.titleLarge,
                    color = Navy900
                )
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("revise_close_button")
                ) {
                    Icon(Icons.Rounded.Close, contentDescription = "إغلاق", tint = Navy900)
                }
            }

            Text(
                text = "اختر توجيهاً سريعاً أو اكتب ملاحظتك، أو عد لتعديل إجابات الاستبيان:",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                quickOptions.forEachIndexed { idx, (chipLabel, chipNote) ->
                    SelectablePillChip(
                        label = chipLabel,
                        selected = note == chipNote,
                        onClick = { note = chipNote },
                        modifier = Modifier.testTag("revise_quick_chip_$idx")
                    )
                }
            }

            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("revise_note_input"),
                label = { Text("ملاحظات التعديل (اختياري)") },
                placeholder = { Text("مثال: ركّز على مشاريع من المنزل بميزانية أقل من 30 ألف ر.ي") },
                minLines = 3,
                shape = RoundedCornerShape(14.dp)
            )

            Button(
                onClick = { onApplyFeedback(note) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("revise_apply_button"),
                colors = ButtonDefaults.buttonColors(containerColor = Orange500, contentColor = PureWhite),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Rounded.EditNote, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("تحديث الأفكار حسب ملاحظاتي", style = MaterialTheme.typography.labelLarge)
            }

            OutlinedButton(
                onClick = onEditQuestionnaire,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("revise_edit_answers_button"),
                border = BorderStroke(1.5.dp, BorderSubtle),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(
                    text = "العودة وتعديل إجابات الاستبيان",
                    style = MaterialTheme.typography.labelLarge,
                    color = Navy900
                )
            }
        }
    }
}
