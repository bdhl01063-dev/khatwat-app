package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.BusinessPlanBundle
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.Navy100
import com.example.ui.theme.Navy900
import com.example.ui.theme.Orange100
import com.example.ui.theme.Orange500
import com.example.ui.theme.Orange600
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SavedPlansScreen(
    plans: List<BusinessPlanBundle>,
    onOpenPlan: (BusinessPlanBundle) -> Unit,
    onDeletePlan: (String) -> Unit,
    onStartNew: () -> Unit,
    onBackHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBackHome() }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 640.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = PureWhite,
                border = BorderStroke(1.dp, BorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("خططي المحفوظة محلياً", style = MaterialTheme.typography.titleLarge, color = Navy900)
                        Text(
                            "محفوظة على جهازك وتعمل بالكامل دون إنترنت.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = onStartNew,
                        modifier = Modifier.testTag("saved_new_plan_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Orange500, contentColor = PureWhite),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("خطة جديدة")
                    }
                }
            }

            if (plans.isEmpty()) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = PureWhite,
                    border = BorderStroke(1.dp, BorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.FolderOpen,
                            contentDescription = null,
                            tint = Orange500,
                            modifier = Modifier.size(44.dp)
                        )
                        Text("لا توجد خطط محفوظة بعد", style = MaterialTheme.typography.titleLarge, color = Navy900)
                        Text(
                            "أكمل استبيان خطوتك لتحصل على 3 مشاريع مخصصة وتُحفظ هنا للرجوع إليها دون إنترنت.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                        Button(
                            onClick = onStartNew,
                            modifier = Modifier.testTag("empty_saved_start_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = Orange500, contentColor = PureWhite),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("ابدأ الاستبيان الآن")
                        }
                    }
                }
            } else {
                plans.forEach { plan ->
                    val pct = plan.overallProgressPercent()
                    val dateStr = SimpleDateFormat("yyyy/MM/dd", Locale.forLanguageTag("ar")).format(Date(plan.createdAt))
                    val mainTitle = plan.ideas.firstOrNull()?.title ?: "خطة مشاريع"
                    val extraCount = (plan.ideas.size - 1).coerceAtLeast(0)

                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = PureWhite,
                        border = BorderStroke(1.dp, BorderSubtle),
                        shadowElevation = 2.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(shape = RoundedCornerShape(999.dp), color = Navy900) {
                                    Text(
                                        text = dateStr,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = PureWhite,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                                Surface(shape = RoundedCornerShape(999.dp), color = Orange100) {
                                    Text(
                                        text = "الإنجاز $pct%",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Orange600,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Text(
                                text = if (extraCount > 0) "$mainTitle (+$extraCount أفكار)" else mainTitle,
                                style = MaterialTheme.typography.titleMedium,
                                color = Navy900,
                                fontWeight = FontWeight.Bold
                            )

                            Text(
                                text = "الميزانية: ${plan.profile.getBudgetLabel()} · ${plan.completedStepsCount()} من ${plan.totalStepsCount()} خطوة",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )

                            LinearProgressIndicator(
                                progress = { pct / 100f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(999.dp)),
                                color = Orange500,
                                trackColor = Navy100
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { onOpenPlan(plan) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("open_saved_plan_${plan.id}"),
                                    colors = ButtonDefaults.buttonColors(containerColor = Navy900, contentColor = PureWhite),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("فتح الخطة")
                                }

                                OutlinedButton(
                                    onClick = { onDeletePlan(plan.id) },
                                    modifier = Modifier
                                        .height(48.dp)
                                        .testTag("delete_saved_plan_${plan.id}"),
                                    border = BorderStroke(1.dp, ErrorRed.copy(alpha = 0.35f)),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.DeleteOutline,
                                        contentDescription = "حذف الخطة",
                                        tint = ErrorRed
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
