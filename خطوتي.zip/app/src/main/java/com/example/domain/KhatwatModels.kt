package com.example.domain

data class OptionItem(
    val id: String,
    val label: String,
    val hint: String = ""
)

data class BudgetOptionItem(
    val id: String,
    val label: String,
    val hint: String,
    val maxYer: Long
)

object KhatwatCatalog {
    const val FINANCIAL_DISCLAIMER_AR =
        "تنبيه استرشادي مهم: جميع التكاليف والعوائد الموضحة هي تقديرات تقريبية بالريال اليمني (YER) مبنية على مدخلاتك وطبيعة السوق، وليست أرباحاً مضمونة أو التزاماً مالياً. تختلف النتائج الفعلية باختلاف الأسعار المحلية، جودة التنفيذ، والطلب الفعلي."

    val skillOptions = listOf(
        OptionItem("design", "التصميم الجرافيكي / Canva"),
        OptionItem("writing", "كتابة المحتوى والإعلانات"),
        OptionItem("social_media", "إدارة حسابات التواصل"),
        OptionItem("programming", "البرمجة وتطوير المواقع"),
        OptionItem("video_edit", "مونتاج الفيديو القصير"),
        OptionItem("teaching", "التدريس والشرح المبسط"),
        OptionItem("cooking", "الطبخ والحلويات المنزلية"),
        OptionItem("crafts", "الحرف اليدوية والإكسسوارات"),
        OptionItem("sales", "البيع والتفاوض والوساطة"),
        OptionItem("photography", "التصوير بالهاتف"),
        OptionItem("phone_repair", "صيانة الهواتف والبرمجيات"),
        OptionItem("translation", "الترجمة وتنسيق الملفات"),
        OptionItem("home_tech", "الصيانة الكهربائية والمنزلية")
    )

    val interestOptions = listOf(
        OptionItem("digital_services", "الخدمات الرقمية والعمل الحر"),
        OptionItem("ecommerce", "التجارة الإلكترونية والبيع أونلاين"),
        OptionItem("food_beverage", "الأطعمة والحلويات والمشروبات"),
        OptionItem("education", "التعليم والتدريب"),
        OptionItem("creative_media", "المحتوى والإعلام الإبداعي"),
        OptionItem("handmade", "الهدايا والمشغولات اليدوية"),
        OptionItem("tech_repair", "التقنية وصيانة الأجهزة"),
        OptionItem("local_services", "الخدمات الميدانية والمحلية")
    )

    val budgetOptions = listOf(
        BudgetOptionItem("zero", "0 ر.ي (بدون رأس مال)", "البدء بالمهارة والهاتف أو اللابتوب فقط", 0L),
        BudgetOptionItem("micro", "أقل من 50,000 ر.ي", "ميزانية تأسيس بسيطة جداً", 50_000L),
        BudgetOptionItem("starter", "50,000 – 150,000 ر.ي", "مناسبة لمستلزمات أولية محدودة", 150_000L),
        BudgetOptionItem("growth", "150,000 – 500,000 ر.ي", "تجهيز مشروع صغير متكامل", 500_000L),
        BudgetOptionItem("expanded", "أكثر من 500,000 ر.ي", "انطلاقة أوسع ومخزون أولي", 1_200_000L)
    )

    val hoursOptions = listOf(
        OptionItem("lt8", "أقل من 8 ساعات أسبوعياً", "جانبي مع الدراسة أو العمل"),
        OptionItem("8_15", "8 – 15 ساعة أسبوعياً", "ساعتان يومياً تقريباً"),
        OptionItem("15_25", "15 – 25 ساعة أسبوعياً", "التزام نصف تفرغ"),
        OptionItem("25_plus", "أكثر من 25 ساعة أسبوعياً", "تفرغ شبه كامل للمشروع")
    )

    val locationOptions = listOf(
        OptionItem("remote", "عمل عن بُعد بالكامل", "عبر الإنترنت من أي مكان"),
        OptionItem("home", "من المنزل بالطلب", "تحضير أو تنفيذ في البيت دون محل"),
        OptionItem("local", "ميداني / محلي في مدينتي", "تواصل وتنفيذ مباشر مع العملاء"),
        OptionItem("flexible", "مرن (لا يهم المكان)", "منفتح على الأنسب لمهاراتي")
    )

    val toolOptions = listOf(
        OptionItem("smartphone", "هاتف ذكي فقط"),
        OptionItem("laptop", "لابتوب / كمبيوتر"),
        OptionItem("internet", "إنترنت مستقر نسبياً"),
        OptionItem("workspace", "مطبخ أو مساحة عمل منزلية"),
        OptionItem("transport", "وسيلة تنقل أو توصيل")
    )

    val experienceOptions = listOf(
        OptionItem("beginner", "مبتدئ", "أملك الأساسيات وأحتاج بداية سهلة"),
        OptionItem("intermediate", "متوسط", "نفذت أعمالاً بسيطة من قبل"),
        OptionItem("advanced", "متمرس", "أبحث عن تنظيم الدخل والتوسع")
    )

    fun formatYer(amount: Long): String {
        val text = amount.toString()
        val sb = StringBuilder()
        var count = 0
        for (i in text.length - 1 downTo 0) {
            sb.append(text[i])
            count++
            if (count % 3 == 0 && i != 0) sb.append(',')
        }
        return sb.reverse().toString()
    }
}

data class QuestionnaireProfile(
    val skills: List<String> = emptyList(),
    val customSkills: List<String> = emptyList(),
    val experienceId: String = "beginner",
    val interests: List<String> = emptyList(),
    val passionNote: String = "",
    val budgetId: String = "zero",
    val customBudgetYer: String = "",
    val hoursId: String = "8_15",
    val locationPreference: String = "flexible",
    val tools: List<String> = listOf("smartphone"),
    val city: String = ""
) {
    private fun normalizeDigits(input: String): String = buildString(input.length) {
        for (ch in input.trim()) {
            when (ch) {
                in '٠'..'٩' -> append(('0'.code + (ch.code - '٠'.code)).toChar())
                in '۰'..'۹' -> append(('0'.code + (ch.code - '۰'.code)).toChar())
                else -> append(ch)
            }
        }
    }

    fun getBudgetMaxYer(): Long {
        val parsed = normalizeDigits(customBudgetYer).toLongOrNull()
        if (parsed != null && parsed >= 0L) return parsed
        return KhatwatCatalog.budgetOptions.find { it.id == budgetId }?.maxYer ?: 0L
    }

    fun getBudgetLabel(): String {
        val parsed = normalizeDigits(customBudgetYer).toLongOrNull()
        if (parsed != null && parsed >= 0L) {
            return "${KhatwatCatalog.formatYer(parsed)} ر.ي (مخصص)"
        }
        return KhatwatCatalog.budgetOptions.find { it.id == budgetId }?.label ?: "0 ر.ي"
    }

    fun getLocationLabel(): String =
        KhatwatCatalog.locationOptions.find { it.id == locationPreference }?.label ?: "مرن"
}

data class CostItem(
    val item: String,
    val range: String
)

data class FinancialEstimate(
    val startupRangeLabel: String,
    val startupItems: List<CostItem>,
    val monthlyExpense: String,
    val monthlyRevenue: String,
    val breakEven: String,
    val disclaimer: String = KhatwatCatalog.FINANCIAL_DISCLAIMER_AR
)

data class ExecutionStep(
    val id: String,
    val title: String,
    val description: String,
    val timeframe: String,
    val completed: Boolean = false
)

data class MarketingPlan(
    val targetAudience: String,
    val channels: List<String>,
    val firstWeekActions: String,
    val pricingTip: String
)

data class BusinessIdea(
    val id: String,
    val rank: Int,
    val title: String,
    val summary: String,
    val workModeLabel: String,
    val reasons: List<String>,
    val financials: FinancialEstimate,
    val steps: List<ExecutionStep>,
    val marketing: MarketingPlan
) {
    fun completedStepsCount(): Int = steps.count { it.completed }
    fun progressPercent(): Int =
        if (steps.isEmpty()) 0 else ((completedStepsCount() * 100f) / steps.size).toInt()
}

data class BusinessPlanBundle(
    val id: String,
    val createdAt: Long,
    val updatedAt: Long,
    val profile: QuestionnaireProfile,
    val source: String,
    val sourceLabel: String,
    val revisionNote: String = "",
    val fallbackNotice: String = "",
    val disclaimer: String = KhatwatCatalog.FINANCIAL_DISCLAIMER_AR,
    val ideas: List<BusinessIdea>
) {
    fun totalStepsCount(): Int = ideas.sumOf { it.steps.size }
    fun completedStepsCount(): Int = ideas.sumOf { it.completedStepsCount() }
    fun overallProgressPercent(): Int {
        val total = totalStepsCount()
        return if (total == 0) 0 else ((completedStepsCount() * 100f) / total).toInt()
    }
}

internal object SimpleJson {
    fun stringify(value: Any?): String {
        val sb = StringBuilder()
        writeValue(value, sb)
        return sb.toString()
    }

    private fun writeValue(value: Any?, sb: StringBuilder) {
        when (value) {
            null -> sb.append("null")
            is Boolean, is Int, is Long, is Double, is Float -> sb.append(value.toString())
            is String -> writeString(value, sb)
            is Map<*, *> -> {
                sb.append('{')
                var first = true
                for ((k, v) in value) {
                    if (!first) sb.append(',')
                    first = false
                    writeString(k.toString(), sb)
                    sb.append(':')
                    writeValue(v, sb)
                }
                sb.append('}')
            }
            is Iterable<*> -> {
                sb.append('[')
                var first = true
                for (item in value) {
                    if (!first) sb.append(',')
                    first = false
                    writeValue(item, sb)
                }
                sb.append(']')
            }
            else -> writeString(value.toString(), sb)
        }
    }

    private fun writeString(s: String, sb: StringBuilder) {
        sb.append('"')
        for (ch in s) {
            when (ch) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\b' -> sb.append("\\b")
                '\u000C' -> sb.append("\\f")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> {
                    if (ch.code < 0x20) {
                        sb.append("\\u").append(ch.code.toString(16).padStart(4, '0'))
                    } else {
                        sb.append(ch)
                    }
                }
            }
        }
        sb.append('"')
    }

    fun parse(input: String): Any? = Parser(input).parseRoot()

    private class Parser(private val src: String) {
        private var pos = 0

        fun parseRoot(): Any? {
            skipWhitespace()
            return parseValue()
        }

        private fun skipWhitespace() {
            while (pos < src.length && src[pos].isWhitespace()) pos++
        }

        private fun parseValue(): Any? {
            skipWhitespace()
            if (pos >= src.length) throw IllegalArgumentException("Unexpected end of JSON")
            return when (src[pos]) {
                '{' -> parseObject()
                '[' -> parseArray()
                '"' -> parseString()
                't' -> { expectLiteral("true"); true }
                'f' -> { expectLiteral("false"); false }
                'n' -> { expectLiteral("null"); null }
                '-', in '0'..'9' -> parseNumber()
                else -> throw IllegalArgumentException("Unexpected JSON char '${src[pos]}' at $pos")
            }
        }

        private fun expectLiteral(lit: String) {
            if (!src.startsWith(lit, pos)) throw IllegalArgumentException("Expected $lit at $pos")
            pos += lit.length
        }

        private fun parseObject(): Map<String, Any?> {
            pos++ // '{'
            val map = linkedMapOf<String, Any?>()
            skipWhitespace()
            if (pos < src.length && src[pos] == '}') {
                pos++
                return map
            }
            while (pos < src.length) {
                skipWhitespace()
                val key = parseString()
                skipWhitespace()
                if (pos >= src.length || src[pos] != ':') throw IllegalArgumentException("Expected ':' at $pos")
                pos++
                val value = parseValue()
                map[key] = value
                skipWhitespace()
                if (pos < src.length && src[pos] == ',') {
                    pos++
                } else if (pos < src.length && src[pos] == '}') {
                    pos++
                    return map
                } else {
                    throw IllegalArgumentException("Expected ',' or '}' at $pos")
                }
            }
            throw IllegalArgumentException("Unterminated JSON object")
        }

        private fun parseArray(): List<Any?> {
            pos++ // '['
            val list = mutableListOf<Any?>()
            skipWhitespace()
            if (pos < src.length && src[pos] == ']') {
                pos++
                return list
            }
            while (pos < src.length) {
                list.add(parseValue())
                skipWhitespace()
                if (pos < src.length && src[pos] == ',') {
                    pos++
                } else if (pos < src.length && src[pos] == ']') {
                    pos++
                    return list
                } else {
                    throw IllegalArgumentException("Expected ',' or ']' at $pos")
                }
            }
            throw IllegalArgumentException("Unterminated JSON array")
        }

        private fun parseString(): String {
            if (src[pos] != '"') throw IllegalArgumentException("Expected '\"' at $pos")
            pos++
            val sb = StringBuilder()
            while (pos < src.length) {
                val ch = src[pos++]
                if (ch == '"') return sb.toString()
                if (ch == '\\') {
                    if (pos >= src.length) throw IllegalArgumentException("Unterminated escape")
                    when (val esc = src[pos++]) {
                        '"' -> sb.append('"')
                        '\\' -> sb.append('\\')
                        '/' -> sb.append('/')
                        'b' -> sb.append('\b')
                        'f' -> sb.append('\u000C')
                        'n' -> sb.append('\n')
                        'r' -> sb.append('\r')
                        't' -> sb.append('\t')
                        'u' -> {
                            val hex = src.substring(pos, pos + 4)
                            sb.append(hex.toInt(16).toChar())
                            pos += 4
                        }
                        else -> sb.append(esc)
                    }
                } else {
                    sb.append(ch)
                }
            }
            throw IllegalArgumentException("Unterminated JSON string")
        }

        private fun parseNumber(): Number {
            val start = pos
            if (src[pos] == '-') pos++
            while (pos < src.length && src[pos] in '0'..'9') pos++
            var isDouble = false
            if (pos < src.length && src[pos] == '.') {
                isDouble = true
                pos++
                while (pos < src.length && src[pos] in '0'..'9') pos++
            }
            if (pos < src.length && (src[pos] == 'e' || src[pos] == 'E')) {
                isDouble = true
                pos++
                if (pos < src.length && (src[pos] == '+' || src[pos] == '-')) pos++
                while (pos < src.length && src[pos] in '0'..'9') pos++
            }
            val token = src.substring(start, pos)
            return if (isDouble) token.toDouble() else token.toLong()
        }
    }
}

object PlanJsonCodec {
    fun profileToJsonString(profile: QuestionnaireProfile): String = SimpleJson.stringify(
        mapOf(
            "skills" to profile.skills,
            "customSkills" to profile.customSkills,
            "experienceId" to profile.experienceId,
            "interests" to profile.interests,
            "passionNote" to profile.passionNote,
            "budgetId" to profile.budgetId,
            "customBudgetYer" to profile.customBudgetYer,
            "hoursId" to profile.hoursId,
            "locationPreference" to profile.locationPreference,
            "tools" to profile.tools,
            "city" to profile.city
        )
    )

    fun profileFromJsonString(jsonStr: String): QuestionnaireProfile {
        val obj = (SimpleJson.parse(jsonStr) as? Map<*, *>) ?: emptyMap<String, Any?>()
        return QuestionnaireProfile(
            skills = obj["skills"].asStringList(),
            customSkills = obj["customSkills"].asStringList(),
            experienceId = obj.str("experienceId", "beginner"),
            interests = obj["interests"].asStringList(),
            passionNote = obj.str("passionNote", ""),
            budgetId = obj.str("budgetId", "zero"),
            customBudgetYer = obj.str("customBudgetYer", ""),
            hoursId = obj.str("hoursId", "8_15"),
            locationPreference = obj.str("locationPreference", "flexible"),
            tools = obj["tools"].asStringList().ifEmpty { listOf("smartphone") },
            city = obj.str("city", "")
        )
    }

    fun ideasToJson(ideas: List<BusinessIdea>): String = SimpleJson.stringify(
        ideas.map { idea ->
            mapOf(
                "id" to idea.id,
                "rank" to idea.rank,
                "title" to idea.title,
                "summary" to idea.summary,
                "workModeLabel" to idea.workModeLabel,
                "reasons" to idea.reasons,
                "financials" to mapOf(
                    "startupRangeLabel" to idea.financials.startupRangeLabel,
                    "monthlyExpense" to idea.financials.monthlyExpense,
                    "monthlyRevenue" to idea.financials.monthlyRevenue,
                    "breakEven" to idea.financials.breakEven,
                    "disclaimer" to idea.financials.disclaimer,
                    "startupItems" to idea.financials.startupItems.map { cost ->
                        mapOf("item" to cost.item, "range" to cost.range)
                    }
                ),
                "steps" to idea.steps.map { step ->
                    mapOf(
                        "id" to step.id,
                        "title" to step.title,
                        "description" to step.description,
                        "timeframe" to step.timeframe,
                        "completed" to step.completed
                    )
                },
                "marketing" to mapOf(
                    "targetAudience" to idea.marketing.targetAudience,
                    "channels" to idea.marketing.channels,
                    "firstWeekActions" to idea.marketing.firstWeekActions,
                    "pricingTip" to idea.marketing.pricingTip
                )
            )
        }
    )

    fun ideasFromJson(jsonStr: String): List<BusinessIdea> {
        val arr = (SimpleJson.parse(jsonStr) as? List<*>) ?: emptyList<Any?>()
        return arr.mapIndexedNotNull { i, item ->
            val obj = item as? Map<*, *> ?: return@mapIndexedNotNull null
            val finObj = obj["financials"] as? Map<*, *> ?: emptyMap<String, Any?>()
            val costList = (finObj["startupItems"] as? List<*>).orEmpty().mapNotNull { c ->
                val co = c as? Map<*, *> ?: return@mapNotNull null
                CostItem(co.str("item"), co.str("range"))
            }
            val stepList = (obj["steps"] as? List<*>).orEmpty().mapNotNull { s ->
                val so = s as? Map<*, *> ?: return@mapNotNull null
                ExecutionStep(
                    id = so.str("id"),
                    title = so.str("title"),
                    description = so.str("description"),
                    timeframe = so.str("timeframe"),
                    completed = (so["completed"] as? Boolean) ?: false
                )
            }
            val mktObj = obj["marketing"] as? Map<*, *> ?: emptyMap<String, Any?>()
            BusinessIdea(
                id = obj.str("id"),
                rank = (obj["rank"] as? Number)?.toInt() ?: (i + 1),
                title = obj.str("title"),
                summary = obj.str("summary"),
                workModeLabel = obj.str("workModeLabel"),
                reasons = obj["reasons"].asStringList(),
                financials = FinancialEstimate(
                    startupRangeLabel = finObj.str("startupRangeLabel"),
                    startupItems = costList,
                    monthlyExpense = finObj.str("monthlyExpense"),
                    monthlyRevenue = finObj.str("monthlyRevenue"),
                    breakEven = finObj.str("breakEven"),
                    disclaimer = finObj.str("disclaimer", KhatwatCatalog.FINANCIAL_DISCLAIMER_AR)
                ),
                steps = stepList,
                marketing = MarketingPlan(
                    targetAudience = mktObj.str("targetAudience"),
                    channels = mktObj["channels"].asStringList(),
                    firstWeekActions = mktObj.str("firstWeekActions"),
                    pricingTip = mktObj.str("pricingTip")
                )
            )
        }
    }

    private fun Map<*, *>.str(key: String, default: String = ""): String {
        val value = this[key] ?: return default
        return value.toString().ifBlank { default }
    }

    private fun Any?.asStringList(): List<String> =
        (this as? List<*>)?.mapNotNull { it?.toString() } ?: emptyList()
}
