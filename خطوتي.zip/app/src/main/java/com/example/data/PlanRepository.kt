package com.example.data

import com.example.data.local.SavedPlanDao
import com.example.data.local.SavedPlanEntity
import com.example.domain.BusinessPlanBundle
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class PlanRepository(
    private val dao: SavedPlanDao
) {
    val savedPlans: Flow<List<BusinessPlanBundle>> =
        dao.observeAllPlans().map { entities ->
            entities.mapNotNull { entity ->
                runCatching { entity.toDomain() }.getOrNull()
            }
        }

    suspend fun savePlan(bundle: BusinessPlanBundle) {
        dao.upsertPlan(SavedPlanEntity.fromDomain(bundle.copy(updatedAt = System.currentTimeMillis())))
    }

    suspend fun deletePlan(planId: String) {
        dao.deletePlanById(planId)
    }

    suspend fun toggleExecutionStep(planId: String, ideaId: String, stepId: String): BusinessPlanBundle? {
        val currentEntity = dao.getPlanById(planId) ?: return null
        val current = currentEntity.toDomain()
        val updatedIdeas = current.ideas.map { idea ->
            if (idea.id != ideaId) {
                idea
            } else {
                idea.copy(
                    steps = idea.steps.map { step ->
                        if (step.id == stepId) step.copy(completed = !step.completed) else step
                    }
                )
            }
        }
        val updatedBundle = current.copy(
            ideas = updatedIdeas,
            updatedAt = System.currentTimeMillis()
        )
        dao.upsertPlan(SavedPlanEntity.fromDomain(updatedBundle))
        return updatedBundle
    }
}
