package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SavedPlanDao {
    @Query("SELECT * FROM saved_plans ORDER BY updatedAt DESC")
    fun observeAllPlans(): Flow<List<SavedPlanEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPlan(plan: SavedPlanEntity)

    @Query("DELETE FROM saved_plans WHERE id = :planId")
    suspend fun deletePlanById(planId: String)

    @Query("SELECT * FROM saved_plans WHERE id = :planId LIMIT 1")
    suspend fun getPlanById(planId: String): SavedPlanEntity?
}
