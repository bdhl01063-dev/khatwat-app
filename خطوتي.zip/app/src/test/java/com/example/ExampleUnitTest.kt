package com.example

import com.example.domain.KhatwatPlanAnalyzer
import com.example.domain.LocalPlanAnalyzer
import com.example.domain.PlanJsonCodec
import com.example.domain.QuestionnaireProfile
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `revise note shifts recommendations to phone only and whatsapp marketing`() {
        val analyzer = LocalPlanAnalyzer()
        val profile = QuestionnaireProfile(
            skills = listOf("programming", "writing", "social_media"),
            interests = listOf("digital_services"),
            budgetId = "starter",
            locationPreference = "flexible",
            tools = listOf("smartphone", "laptop", "internet")
        )

        val revised = analyzer.analyze(
            profile = profile,
            revisionNote = "أريد أفكاراً بالهاتف فقط وعن بُعد وأقل تكلفة مع تسويق عبر واتساب"
        )

        assertEquals(3, revised.ideas.size)
        assertEquals(3, revised.ideas.map { it.title }.toSet().size)
        assertTrue(revised.ideas.none { it.title.contains("صفحات هبوط") })
        assertTrue(revised.ideas.first().marketing.channels.any { it.contains("واتساب") })
        assertTrue(revised.ideas.first().financials.disclaimer.contains("ليست أرباحاً مضمونة"))
    }

    @Test
    fun `arabic indic budget digits and json roundtrip preserve profile and step progress`() {
        val profile = QuestionnaireProfile(
            skills = listOf("design", "writing"),
            customSkills = listOf("تصميم بوسترات"),
            interests = listOf("creative_media"),
            budgetId = "micro",
            customBudgetYer = "٣٥٠٠٠",
            locationPreference = "remote",
            city = "صنعاء"
        )

        assertEquals(35_000L, profile.getBudgetMaxYer())
        assertTrue(profile.getBudgetLabel().contains("35,000"))

        val profileJson = PlanJsonCodec.profileToJsonString(profile)
        val restoredProfile = PlanJsonCodec.profileFromJsonString(profileJson)
        assertEquals(profile.skills, restoredProfile.skills)
        assertEquals(profile.customSkills, restoredProfile.customSkills)
        assertEquals("٣٥٠٠٠", restoredProfile.customBudgetYer)
        assertEquals("صنعاء", restoredProfile.city)

        val bundle = LocalPlanAnalyzer().analyze(profile)
        val updatedIdeas = bundle.ideas.mapIndexed { idx, idea ->
            if (idx == 0) {
                idea.copy(steps = idea.steps.mapIndexed { sIdx, step ->
                    if (sIdx == 0) step.copy(completed = true) else step
                })
            } else idea
        }

        val json = PlanJsonCodec.ideasToJson(updatedIdeas)
        val restored = PlanJsonCodec.ideasFromJson(json)

        assertEquals(3, restored.size)
        assertEquals(bundle.ideas[0].title, restored[0].title)
        assertTrue(restored[0].steps[0].completed)
        assertFalse(restored[0].steps[1].completed)
    }

    @Test
    fun `optional gemini analyzer falls back cleanly to local results when disabled or invalid`() = runBlocking {
        val analyzer = KhatwatPlanAnalyzer()
        val profile = QuestionnaireProfile(
            skills = listOf("writing"),
            interests = listOf("digital_services"),
            tools = listOf("smartphone")
        )

        val localResult = analyzer.analyze(profile, useOptionalGemini = false)
        assertEquals("local", localResult.source)
        assertEquals(3, localResult.ideas.size)
    }
}
